/* eslint-disable */
<template>
    <div class="antialiased text-slate-100 bg-slate-900">
        <div class="flex w-full h-screen justify-center items-center">
            <div class="container">

            </div>
        </div>
    </div>
</template>

<script>


export default {

    name: 'Countdown',
    created() {
        console.log(2)
        var scripts = [
            "https://code.jquery.com/jquery-3.7.1.slim.min.js"
        ];
        scripts.forEach(script => {
            let tag = document.createElement("script");
            tag.setAttribute("src", script);
            document.head.appendChild(tag);
        });
    },
    mounted() {


        var counter = 3;

        var timer = setInterval(function () {

            $('#countdown').remove();

            var countdown = $('<span id="countdown">' + (counter == 0 ? 'BEGIN!' : counter) + '</span>');
            countdown.appendTo($('.container'));
            setTimeout(() => {
                if (counter > -1) {
                    $('#countdown').css({ 'font-size': '20vw', 'opacity': 0 });
                } else {
                    $('#countdown').css({ 'font-size': '10vw', 'opacity': 10 });
                }
            }, 20);
            counter--;
            if (counter == -1) {
                clearInterval(timer)
                window.location.href = "#/Quiz"
            };
        }, 1000);
    }
}

</script>

<style>
#countdown {
    position: absolute;
    left: 50%;
    top: 50%;
    display: inline-block;
    transform: translate(-50%, -50%);
    transition: 1s;
    font-size: 0vw;
    opacity: 50%;
}
</style>